package main

type computer interface {
	insertIntoLightningPort()
}
