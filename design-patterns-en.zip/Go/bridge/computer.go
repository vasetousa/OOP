package main

type computer interface {
	print()
	setPrinter(printer)
}
