from project.astronaut.biologist import Biologist
from collections import deque


class SpaceStation:
    def __init__(self):
        self.planet_repository = []
        self.astronaut_repository = []

    def add_astronaut(self, astronaut_type, name):

        if type(astronaut_type) != "Biologist":
            raise Exception("Astronaut type is not valid!")
        astro = [a for a in self.astronaut_repository if a.name == name][0]
        if not astro:
            astronaut_type(name)
            self.astronaut_repository.append(astronaut_type)
            return f"Successfully added {astronaut_type}: {name}."
        return f"{name} is already added."


    def add_planet(self, name, items):
        items_list = items.split(", ")
        planet_name = [p for p in self.astronaut_repository if p.name == name][0]
        if not planet_name:
            plan = planet_name(name, items_list)
            self.planet_repository.append(plan)
            return f"Successfully added Planet: {name}."
        return f"{name} is already added."


    def retire_astronaut(self, name):
        find_astro = [aso for aso in self.astronaut_repository if aso.name == name][0]
        if find_astro:
            self.astronaut_repository.remove(find_astro)
            return f"Astronaut {find_astro} was retired!"
        raise Exception(f"Astronaut {name} doesn't exists!")


    def recharge_oxygen(self):
        for astro in self.astronaut_repository:
            astro.oxygen += 10

    def send_on_mission(self, planet_name):
        astro_count = 0
        find_planet = [pl for pl in self.planet_repository if pl.name == planet_name][0]
        if not find_planet:
            raise Exception("Invalid planet name!")
        astronauts_above_30_oxy = sorted([astron for astron in self.astronaut_repository if astron.oxygen > 30])
        if len(astronauts_above_30_oxy) == 0:
            raise Exception("You need at least one astronaut to explore the planet!")
        astronauts_above_30_oxy = deque(astronauts_above_30_oxy)
        while astronauts_above_30_oxy:
            astro = astronauts_above_30_oxy[0]
            item = find_planet.items_list[-1]
            item.pop()
            astro.breathe()
            if astro.oxygen <= 0:
                astronauts_above_30_oxy.popleft()
                astro_count += 1
            if len(item) == 0:
                return f"Planet: {planet_name} was explored. {astro_count} astronauts participated in collecting items."
        return "Mission is not completed."

    def report(self):
        pass