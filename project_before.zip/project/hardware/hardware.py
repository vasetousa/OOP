from project.software import software
from project.software.software import Software


class Hardware:
    def __init__(self, name, type, capacity, memory):
        self.name = name
        self.type = type
        self.capacity = capacity
        self.memory = memory
        self.software_components = []


    def install(self, software):
        self.software_components.append(software)

    def uninstall(self, software):
        self.software_components.remove(software)

    def check_install_possible(self):
        lenny = len(self.software_components)
        if lenny > self.capacity and lenny > self.memory:
            raise Exception("Software cannot be installed")
        return True