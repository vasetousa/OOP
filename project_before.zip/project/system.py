from project.hardware.hardware import Hardware
from project.hardware.heavy_hardware import HeavyHardware
from project.hardware.power_hardware import PowerHardware
from project.software.express_software import ExpressSoftware


class System:
    _hardware = []
    _software = []

    @staticmethod
    def register_power_hardware(name, capacity, memory):
        phdr = PowerHardware(name, capacity, memory)
        System._hardware.append(phdr)

    @staticmethod
    def register_heavy_hardware(name, capacity, memory):
        hhhdr = HeavyHardware(name, capacity, memory)
        System._hardware.append(hhhdr)

    @staticmethod
    def register_express_software(hardware_name, name, capacity_consumption, memory_consumption):
        hard = [h for h in System._hardware if h.name == hardware_name][0]
        if not hard:
                return "Hardware does not exist"
        result = Hardware.check_install_possible
        if result:
            exprsftr = ExpressSoftware(name, capacity_consumption, memory_consumption)
            Hardware.install(hard, exprsftr)

    @staticmethod
    def register_light_software(hardware_name, name, capacity_consumption, memory_consumption):
        hardo = [h for h in System._hardware if h.name == hardware_name][0]
        if not hardo:
            return "Hardware does not exist"
        result = Hardware.check_install_possible(hardo)
        if result:
            lghtsftr = ExpressSoftware(name, capacity_consumption, memory_consumption)
            Hardware.install(hardo, lghtsftr)

    @staticmethod
    def release_software_component(hardware_name, software_name):
        pass

    @staticmethod
    def analyze():
        pass

    @staticmethod
    def system_split():
        pass



# h = Hardware("Py", "Py-Soft", 10, 10)
# s = System()
# s.register_power_hardware("Py", 100, 100)
# s.register_express_software("Py", "Heavy", 10, 10)
